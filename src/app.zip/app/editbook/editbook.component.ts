import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editbook',
  templateUrl: './editbook.component.html',
  styleUrls: ['./editbook.component.css']
})
export class EditbookComponent implements OnInit {

  bookList = [];
  
  constructor() { }

  ngOnInit(): void {
  }

  // When user clicks on update button to submit updated value  
  updateBook() {  
    
  }
}
